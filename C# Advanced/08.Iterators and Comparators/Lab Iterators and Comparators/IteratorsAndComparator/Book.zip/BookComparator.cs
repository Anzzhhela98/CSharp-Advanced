﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparator
{
    class BookComparator : IComparer<Book>
    {
    }
}
