﻿namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Coffee coffe = new Coffee("Lavaza", 30);

            System.Console.WriteLine(coffe.ToString());
        }
    }
}