﻿namespace _01.ClassBoxData.Common
{
    public static class GlobalConstants
    {

        public static string ExepsionInvalidParameters
            = "{0} cannot be zero or negative.";
    }
}
