﻿
namespace Zoo
{
    public class Animal
    {
        public Animal(string name)
        {
            this.Name = name;
        }

        public string Name
        {
            get { return Name; }
            set { Name = value; }
        }
    }
}
