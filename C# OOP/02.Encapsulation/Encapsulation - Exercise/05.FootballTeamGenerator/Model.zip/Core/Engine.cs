﻿using _05.FootballTeamGenerator.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _05.FootballTeamGenerator.Core
{
    public class Engine
    {
        public void Run()
        {
            List<Team> teams = new List<Team>();

            string command = string.Empty;

            while ((command = Console.ReadLine()) != "END")
            {
                try
                {
                    string[] dataPlayer = command
                              .Split(";")
                              .ToArray();

                    string currentCommand = dataPlayer[0];
                    var teamName = dataPlayer[1];
                    var playerName = string.Empty;

                    switch (currentCommand)
                    {
                        case "Team":

                            Team team = new Team(teamName);
                            teams.Add(team);

                            break;

                        case "Add":
                            playerName = dataPlayer[2];
                            if (!teams.Any(n => n.TeamName == teamName))
                            {
                                throw new ArgumentException
                                    (String.Format(Common.Validator.INVALID_TEAM_NAME, teamName));
                            }

                            int endurance = int.Parse(dataPlayer[3]);
                            int sprint = int.Parse(dataPlayer[4]);
                            int dribble = int.Parse(dataPlayer[5]);
                            int passing = int.Parse(dataPlayer[6]);
                            int shooting = int.Parse(dataPlayer[7]);

                            Stats stats = new Stats(endurance, sprint, dribble, passing, shooting);

                            Player player = new Player(playerName, stats);

                            team = teams.FirstOrDefault(x => x.TeamName == teamName);

                            team.Addplayer(player);

                            break;

                        case "Remove":
                            playerName = dataPlayer[2];

                            team = teams.FirstOrDefault(x => x.TeamName == teamName);

                            team.RemovePlayer(playerName);
                            break;
                        case "Rating":

                            if (!teams.Any(n => n.TeamName == teamName))
                            {
                                throw new ArgumentException(String.Format(Common.Validator.INVALID_TEAM_NAME, teamName));
                            }

                            foreach (var item in teams)
                            {
                                if (item.TeamName == teamName)
                                {
                                    Console.WriteLine(item.ToString());
                                }
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
