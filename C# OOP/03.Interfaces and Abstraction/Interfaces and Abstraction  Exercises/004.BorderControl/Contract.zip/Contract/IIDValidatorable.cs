﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _004.BorderControl
{
    public interface IIDValidatorable
    {
        public string ID { get;  set; }
        //public string CheckLastDigit(string ID);
    }
}
