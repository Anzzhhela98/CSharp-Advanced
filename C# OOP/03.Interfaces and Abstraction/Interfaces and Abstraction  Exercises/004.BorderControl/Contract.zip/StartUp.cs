﻿using _004.BorderControl.Core;
namespace _004.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
