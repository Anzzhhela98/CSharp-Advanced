﻿

namespace _03.Ferrari
{
    interface IDriveable
    {
        public string Brakes();
        public string Push();
    }
}
