﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.Telephony.Contract
{
    public interface IBrowsing
    {
        public string Browsing(string site);
    }
}
