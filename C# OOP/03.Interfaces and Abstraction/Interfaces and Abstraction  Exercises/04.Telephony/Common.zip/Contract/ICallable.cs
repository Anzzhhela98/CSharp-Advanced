﻿namespace _04.Telephony.Contract
{
    public interface ICallable
    {
        public string Calling(string number);

    }
}
