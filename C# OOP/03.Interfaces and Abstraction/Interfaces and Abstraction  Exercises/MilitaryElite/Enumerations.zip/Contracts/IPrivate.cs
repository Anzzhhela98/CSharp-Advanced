﻿namespace _MilitaryElite
{
    public interface IPrivate : ISoldier //? why its not over other prop
    {
         decimal Salary { get; }
    }
}
