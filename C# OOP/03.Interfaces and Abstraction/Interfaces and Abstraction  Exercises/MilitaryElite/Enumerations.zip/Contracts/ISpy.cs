﻿namespace _MilitaryElite.Contracts
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}
