﻿namespace _MilitaryElite.Core
{
    public interface IEngine
    {
        void Run();
    }
}
