﻿namespace _MilitaryElite.Enumerations
{
    public enum Corps
    {
        Airforces = 1,
        Marines = 2,
    }
}
