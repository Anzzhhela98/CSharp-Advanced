﻿namespace _MilitaryElite.Enumerations
{
    public enum State
    {
        InProgress = 1,
        Finished = 2,
    }
}
