﻿namespace _MilitaryElite.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
