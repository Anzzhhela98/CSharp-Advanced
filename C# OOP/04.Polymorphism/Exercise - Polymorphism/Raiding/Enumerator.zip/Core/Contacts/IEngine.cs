﻿namespace Raiding.Core
{
    interface IEngine
    {
        void Run();
    }
}
