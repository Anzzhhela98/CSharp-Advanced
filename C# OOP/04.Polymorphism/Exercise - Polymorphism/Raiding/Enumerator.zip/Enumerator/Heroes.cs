﻿namespace Raiding.Enumerator
{
    public enum Heroes
    {
        Druid,
        Paladin,
        Rogue,
        Warrior,
    }
}
