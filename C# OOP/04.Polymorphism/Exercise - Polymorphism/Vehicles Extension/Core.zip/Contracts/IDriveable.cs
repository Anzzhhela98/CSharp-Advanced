﻿namespace VehiclesExtension.Contracts
{
    public interface IDriveable
    {
        void Drive(double distance);
    }
}
