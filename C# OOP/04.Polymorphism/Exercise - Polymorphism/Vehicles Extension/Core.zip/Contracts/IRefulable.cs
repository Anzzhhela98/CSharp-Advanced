﻿namespace VehiclesExtension.Contracts
{
   public  interface IRefulable
    {
        void Refuel(double fuel);
    }
}
