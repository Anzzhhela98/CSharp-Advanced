﻿namespace VehiclesExtension.Core
{
    public interface IEngine
    {
        void Run();
    }
}
