﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Common
{
    public static class Exeptions
    {
        public static string ExeptionOverloadFuel = "{0} needs refueling";
        public static string InvalidTypeExeptionMessage = "Invalid Vehicle type";
    }
}
