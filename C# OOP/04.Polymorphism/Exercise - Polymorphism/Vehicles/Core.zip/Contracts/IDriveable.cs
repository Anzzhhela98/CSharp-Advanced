﻿namespace Vehicles.Contracts
{
    interface IDriveable
    {
        string Drive(double distance);
    }
}
