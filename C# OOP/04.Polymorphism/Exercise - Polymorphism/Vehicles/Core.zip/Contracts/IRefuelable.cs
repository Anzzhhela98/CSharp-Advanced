﻿namespace Vehicles.Contracts
{
    interface IRefuelable
    {
        void Refuel(double fuel);
    }
}
