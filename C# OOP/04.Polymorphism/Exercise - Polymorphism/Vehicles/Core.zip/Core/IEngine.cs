﻿namespace Vehicles.Core
{
    interface IEngine
    {
        void Run();

    }
}
