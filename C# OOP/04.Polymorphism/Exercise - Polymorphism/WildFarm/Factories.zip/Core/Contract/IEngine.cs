﻿namespace WildFarm.Core
{
    interface IEngine
    {
        void Run();

    }
}
