﻿using System;
using WildFarm.Core;

namespace WildFarm
{
    class StartUp
    {
        static void Main(string[] args)
        {
            IEngine engine = new Engine();
            engine.Run();
        }
    }
}
