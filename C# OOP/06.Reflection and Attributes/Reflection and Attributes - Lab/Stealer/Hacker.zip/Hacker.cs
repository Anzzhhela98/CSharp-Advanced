﻿
namespace Stealer
{
    public class Hacker
    {
        private string username = "securityGod82";
        private string password = "mySuperSecretPassw0rd";

        public string PassWord
        {
            get => this.password;
            set => this.password = value;
        }

        public int Id { get; set; }
        public double BankAccountBalance { get; private set; }
        public void DownloadAllBankAccountsInTheWorld()
        {

        }
    }
}
